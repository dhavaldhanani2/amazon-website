export default function Footer(){
    return(
    <footer className="bg-dark text-center text-light py-2">
  <p>All Right Reserved.</p>
  </footer>

 
    )
}