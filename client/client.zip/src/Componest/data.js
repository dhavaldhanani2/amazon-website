// const products=[
//     {
//         _id:'1',
//         name:'Levis shirt',
//         category:'shirt',
//         Image:"../img/p1.jpg",
//         price:60,
//         brand:'Levis',
//         rating:5.2,
//         numReviews:5,
//         countinstock:6
//     },{
//         _id:'2',
//         name:'Levis pant',
//         category:'pant',
//         Image:"../img/p2.jpg",
//         price:50,
//         brand:'Nike',
//         rating:3.0,
//         numReviews:8,
//         countinstock:6
//     },{
//         _id:'3',
//         name:'Slim shirt',
//         category:'slim shirt',
//         Image:"../img/s.jpg",
//         price:70,
//         brand:'Denim',
//         rating:2.5,
//         numReviews:7,
//         countinstock:6
//     },{
//         _id:'4',
//         name:'Slim pant',
//         category:'pant',
//         Image:"../img/v.jpg",
//         price:90,
//         brand:'Levis',
//         rating:4.5,
//         numReviews:9,
//         countinstock:6
//     }
// ]
// export default products;